import { Module } from "../Module";

export class NPModule extends Module {

    constructor() {
        super("NPModule", false, 49, false);
    }
}