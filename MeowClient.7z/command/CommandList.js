export class CommandList {
    static commands = new Set();
}