export class Command {

    /**
     * 
     * @param {array} aliases command aliases
     */
    constructor(aliases) {
        this.aliases = aliases;
    }
    
}